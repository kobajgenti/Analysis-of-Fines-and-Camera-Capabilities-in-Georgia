package com.lo.borbalo.navigation.launch

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lo.borbalo.navigation.databinding.ItemPermissionsBinding

@SuppressLint("NotifyDataSetChanged")
class PermissionsAdapter : RecyclerView.Adapter<PermissionsAdapter.ViewHolder>() {

    var items: List<Item> = emptyList()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPermissionsBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val view = holder.binding.root
        view.text = item.name
        view.isChecked = item.isGranted
    }

    override fun getItemCount(): Int = items.size

    override fun getItemId(position: Int): Long = position.toLong()

    class ViewHolder(
        val binding: ItemPermissionsBinding
    ) : RecyclerView.ViewHolder(binding.root)

    class Item(
        val name: String,
        val isGranted: Boolean,
    )
}