package com.lo.borbalo.navigation.data

data class CameraCoordinate (
    val x: Double,
    val y: Double,
)