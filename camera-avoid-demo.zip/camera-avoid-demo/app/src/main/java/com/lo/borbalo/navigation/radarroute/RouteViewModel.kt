package com.lo.borbalo.navigation.radarroute

import androidx.lifecycle.ViewModel
import com.lo.borbalo.navigation.data.CameraCoordinate
import com.mapbox.geojson.Point
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update


class RouteViewModel : ViewModel() {

    private val _radars = MutableStateFlow(emptySet<CameraCoordinate>())
    val radars = _radars.asStateFlow()


    fun addRadar(radar: CameraCoordinate) {
        _radars.update { it + radar }
    }


    fun addRadar(point: Point) {
        _radars.update { it + point.toCamera() }
    }

    fun removeRadar(point: Point) {
        _radars.update { it - point.toCamera() }
    }

    private fun Point.toCamera() = CameraCoordinate(longitude(), latitude())

}