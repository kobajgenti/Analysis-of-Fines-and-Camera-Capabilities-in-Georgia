package com.lo.borbalo.navigation.map

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import com.lo.borbalo.navigation.R
import com.lo.borbalo.navigation.addSystemBottomPadding
import com.lo.borbalo.navigation.addSystemTopPadding
import com.lo.borbalo.navigation.databinding.FragmentMapNavigationBinding
import com.mapbox.common.location.Location
import com.mapbox.geojson.Point
import com.mapbox.maps.CameraOptions
import com.mapbox.maps.MapView
import com.mapbox.maps.Style
import com.mapbox.maps.plugin.PuckBearing
import com.mapbox.maps.plugin.animation.MapAnimationOptions
import com.mapbox.maps.plugin.animation.camera
import com.mapbox.maps.plugin.locationcomponent.location
import com.mapbox.navigation.base.options.NavigationOptions
import com.mapbox.navigation.core.MapboxNavigation
import com.mapbox.navigation.core.lifecycle.MapboxNavigationApp
import com.mapbox.navigation.core.lifecycle.MapboxNavigationObserver
import com.mapbox.navigation.core.lifecycle.requireMapboxNavigation
import com.mapbox.navigation.core.trip.session.LocationMatcherResult
import com.mapbox.navigation.core.trip.session.LocationObserver
import com.mapbox.navigation.ui.maps.location.NavigationLocationProvider

class MapNavigationFragment : Fragment(R.layout.fragment_map_navigation) {

    companion object {
        private const val ARG_WITH_FOREGROUND_SERVICE = "withForegroundService"
        fun newInstance(withForegroundService: Boolean): MapNavigationFragment {
            val args = bundleOf(ARG_WITH_FOREGROUND_SERVICE to withForegroundService)
            val fragment = MapNavigationFragment()
            fragment.arguments = args
            return fragment
        }
    }

    private var mapView: MapView? = null
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val binding = FragmentMapNavigationBinding.bind(view)
        binding.toolbar.setNavigationOnClickListener { requireActivity().onBackPressedDispatcher.onBackPressed() }
        binding.toolbar.addSystemTopPadding()
        binding.root.addSystemBottomPadding()
        mapView = binding.mapView
        binding.mapView.mapboxMap.loadStyle(Style.STANDARD)
        binding.mapView.location.apply {
            setLocationProvider(navigationLocationProvider)
            locationPuck = LocationPuckBuilder.build()
            puckBearingEnabled = true
            puckBearing = PuckBearing.COURSE
            enabled = true
        }
    }

    override fun onDestroyView() {
        mapView = null
        super.onDestroyView()
    }

    private val navigationLocationProvider = NavigationLocationProvider()
    private val locationObserver = object : LocationObserver {
        override fun onNewLocationMatcherResult(locationMatcherResult: LocationMatcherResult) {
            val enhancedLocation = locationMatcherResult.enhancedLocation
            navigationLocationProvider.changePosition(
                enhancedLocation, locationMatcherResult.keyPoints,
            )
            updateCamera(enhancedLocation)
        }

        override fun onNewRawLocation(rawLocation: Location) = Unit
    }


    private val mapboxNavigation: MapboxNavigation by requireMapboxNavigation(
        onResumedObserver = object : MapboxNavigationObserver {
            @SuppressLint("MissingPermission")
            override fun onAttached(mapboxNavigation: MapboxNavigation) {
                mapboxNavigation.registerLocationObserver(locationObserver)
                val withForegroundService =
                    arguments?.getBoolean(ARG_WITH_FOREGROUND_SERVICE, false) == true
                mapboxNavigation.startTripSession(withForegroundService)
            }

            override fun onDetached(mapboxNavigation: MapboxNavigation) {
                mapboxNavigation.unregisterLocationObserver(locationObserver)
            }
        },
        onInitialize = {
            val context = activity?.applicationContext ?: return@requireMapboxNavigation
            MapboxNavigationApp.setup {
                NavigationOptions.Builder(applicationContext = context).build()
            }
        }
    )

    private fun updateCamera(location: Location) {
        mapView?.camera?.easeTo(
            CameraOptions.Builder()
                .center(Point.fromLngLat(location.longitude, location.latitude))
                .zoom(18.0)
                .build(),
            MapAnimationOptions.Builder().build()
        )
    }
}