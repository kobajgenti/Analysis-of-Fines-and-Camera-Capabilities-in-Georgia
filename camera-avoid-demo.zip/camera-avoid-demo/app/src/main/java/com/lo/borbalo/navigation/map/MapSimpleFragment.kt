package com.lo.borbalo.navigation.map

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.lo.borbalo.navigation.R
import com.lo.borbalo.navigation.addSystemBottomPadding
import com.lo.borbalo.navigation.addSystemTopPadding
import com.lo.borbalo.navigation.databinding.FragmentMapSimpleBinding
import com.mapbox.android.gestures.MoveGestureDetector
import com.mapbox.maps.CameraOptions
import com.mapbox.maps.MapView
import com.mapbox.maps.Style
import com.mapbox.maps.plugin.PuckBearing
import com.mapbox.maps.plugin.gestures.OnMoveListener
import com.mapbox.maps.plugin.gestures.gestures
import com.mapbox.maps.plugin.locationcomponent.OnIndicatorBearingChangedListener
import com.mapbox.maps.plugin.locationcomponent.OnIndicatorPositionChangedListener
import com.mapbox.maps.plugin.locationcomponent.location


class MapSimpleFragment : Fragment(R.layout.fragment_map_simple) {

    private var mapView: MapView? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val binding = FragmentMapSimpleBinding.bind(view)
        binding.toolbar.setNavigationOnClickListener { requireActivity().onBackPressedDispatcher.onBackPressed() }
        binding.toolbar.addSystemTopPadding()
        binding.root.addSystemBottomPadding()
        mapView = binding.mapView
        binding.mapView.mapboxMap.loadStyle(Style.STANDARD) {
            initLocationComponent()
            setupGesturesListener()
        }
        binding.mapView.location.apply {
            locationPuck = LocationPuckBuilder.build()
            puckBearingEnabled = true
            puckBearing = PuckBearing.HEADING
            enabled = true
        }

    }

    private fun setupGesturesListener() {
        mapView?.gestures?.addOnMoveListener(onMoveListener)
    }

    private fun initLocationComponent() {
        val location = mapView?.location ?: return
        location.addOnIndicatorPositionChangedListener(onIndicatorPositionChangedListener)
        location.addOnIndicatorBearingChangedListener(onIndicatorBearingChangedListener)
    }

    private val onIndicatorBearingChangedListener = OnIndicatorBearingChangedListener {
        mapView?.mapboxMap?.setCamera(CameraOptions.Builder().bearing(it).build())
    }

    private val onIndicatorPositionChangedListener = OnIndicatorPositionChangedListener {
        mapView?.mapboxMap?.setCamera(CameraOptions.Builder().center(it).zoom(18.0).build())
        mapView?.gestures?.focalPoint = mapView?.mapboxMap?.pixelForCoordinate(it)
    }

    private val onMoveListener = object : OnMoveListener {
        override fun onMoveBegin(detector: MoveGestureDetector) {
            onCameraTrackingDismissed()
        }

        override fun onMove(detector: MoveGestureDetector): Boolean {
            return false
        }

        override fun onMoveEnd(detector: MoveGestureDetector) {}
    }

    override fun onDestroyView() {
        mapView?.location?.removeOnIndicatorBearingChangedListener(onIndicatorBearingChangedListener)
        mapView?.location?.removeOnIndicatorPositionChangedListener(
            onIndicatorPositionChangedListener
        )
        mapView?.gestures?.removeOnMoveListener(onMoveListener)
        mapView = null
        super.onDestroyView()
    }

    private fun onCameraTrackingDismissed() {
        mapView?.location?.removeOnIndicatorPositionChangedListener(
            onIndicatorPositionChangedListener
        )
        mapView?.location?.removeOnIndicatorBearingChangedListener(onIndicatorBearingChangedListener)
        mapView?.gestures?.removeOnMoveListener(onMoveListener)
    }

}