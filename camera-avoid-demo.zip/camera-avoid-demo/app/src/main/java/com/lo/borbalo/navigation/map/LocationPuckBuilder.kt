package com.lo.borbalo.navigation.map

import com.mapbox.maps.MapboxExperimental
import com.mapbox.maps.plugin.LocationPuck3D
import com.mapbox.maps.plugin.ModelScaleMode

internal object LocationPuckBuilder {


    @OptIn(MapboxExperimental::class)
    fun build(): com.mapbox.maps.plugin.LocationPuck {
        return LocationPuck3D(
            modelUri = "asset://borbalo_car.glb",
            modelScaleMode = ModelScaleMode.MAP,
            modelScale = listOf(3f, 3f, 3f),
            modelRotation = listOf(0f, 0f, 90f),
        )
    }

    @OptIn(MapboxExperimental::class)
    fun build2(): com.mapbox.maps.plugin.LocationPuck {
        return LocationPuck3D(
            modelUri = "asset://borbalo_car.glb",
            modelScaleMode = ModelScaleMode.VIEWPORT,
            modelScale = listOf(12f, 12f, 12f),
            modelRotation = listOf(0f, 0f, 90f),
        )
    }

}
