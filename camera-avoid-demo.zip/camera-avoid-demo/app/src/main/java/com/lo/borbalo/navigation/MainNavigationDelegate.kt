package com.lo.borbalo.navigation

interface MainNavigationDelegate {

    fun openSimpleMap()

    fun openNavigation(withForegroundService: Boolean)

    fun openRoute()

}