package com.lo.borbalo.navigation

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.commit
import androidx.fragment.app.replace
import com.lo.borbalo.navigation.launch.LaunchFragment
import com.lo.borbalo.navigation.map.MapNavigationFragment
import com.lo.borbalo.navigation.map.MapSimpleFragment
import com.lo.borbalo.navigation.radarroute.RouteActivity

class MainActivity : AppCompatActivity(), MainNavigationDelegate {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContentView(R.layout.activity_main)
        if (savedInstanceState == null) {
            openLaunch()
        }

    }

    private fun openLaunch() {
        supportFragmentManager.commit {
            setReorderingAllowed(true)
            replace<LaunchFragment>(R.id.fragment_container)
        }
    }

    override fun openSimpleMap() {
        supportFragmentManager.commit {
            setReorderingAllowed(true)
            replace<MapSimpleFragment>(R.id.fragment_container)
            addToBackStack("simple_map")
        }
    }

    override fun openNavigation(withForegroundService: Boolean) {
        supportFragmentManager.commit {
            setReorderingAllowed(true)
            val fragment = MapNavigationFragment.newInstance(withForegroundService)
            replace(R.id.fragment_container, fragment)
            addToBackStack("navigation")
        }
    }

    override fun openRoute() {
        startActivity(Intent(this, RouteActivity::class.java))
    }

}