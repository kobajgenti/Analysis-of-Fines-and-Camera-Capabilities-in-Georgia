package com.lo.borbalo.navigation.launch

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.lo.borbalo.navigation.MainNavigationDelegate
import com.lo.borbalo.navigation.R
import com.lo.borbalo.navigation.addSystemBottomPadding
import com.lo.borbalo.navigation.addSystemTopPadding
import com.lo.borbalo.navigation.databinding.FragmentLaunchBinding


class LaunchFragment : Fragment(R.layout.fragment_launch) {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { view?.post { updatePermissionState() } }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val binding = FragmentLaunchBinding.bind(view)
        binding.toolbar.addSystemTopPadding()
        binding.scrollView.addSystemBottomPadding()
        initAdapter(binding)
        initButtons(binding)
        view.post { updatePermissionState() }
    }

    private fun initButtons(binding: FragmentLaunchBinding) {
        binding.settingsButton.setOnClickListener {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            val uri = Uri.fromParts("package", requireContext().packageName, null)
            intent.setData(uri)
            startActivity(intent)
        }
        binding.requestButton.setOnClickListener {
            val permissions = mutableListOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            permissionLauncher.launch(permissions.toTypedArray())
        }
        binding.simpleMapScreen.setOnClickListener { openSimpleMap() }
        binding.navScreen.setOnClickListener { openNavigation(withForegroundService = false) }
        binding.navServiceScreen.setOnClickListener { openNavigation(withForegroundService = true) }
        binding.routeScreen.setOnClickListener { openRoute() }
    }

    override fun onStart() {
        super.onStart()
        updatePermissionState()
    }

    private fun openSimpleMap() {
        if (!isLocationGranted()) return
        val delegate = requireActivity() as MainNavigationDelegate
        delegate.openSimpleMap()
    }

    private fun openNavigation(withForegroundService: Boolean) {
        if (!isLocationGranted()) return
        val delegate = requireActivity() as MainNavigationDelegate
        delegate.openNavigation(withForegroundService)
    }

    private fun openRoute() {
        if (!isLocationGranted()) return
        val delegate = requireActivity() as MainNavigationDelegate
        delegate.openRoute()
    }


    private fun isLocationGranted(): Boolean {
        val context = context ?: return false
        val isAccessFineLocationGranted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val isAccessCoarseLocationGranted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val isLocationGranted = isAccessFineLocationGranted && isAccessCoarseLocationGranted
        if (!isLocationGranted) {
            Toast.makeText(context, "Location permission not granted", Toast.LENGTH_SHORT).show()
        }
        return isLocationGranted
    }

    private fun initAdapter(binding: FragmentLaunchBinding) {
        binding.permissionList.layoutManager = LinearLayoutManager(context)
        binding.permissionList.adapter = PermissionsAdapter()
    }

    private fun updatePermissionState() {
        val context = context ?: return
        val adapter =
            view?.let(FragmentLaunchBinding::bind)
                ?.permissionList?.adapter as? PermissionsAdapter
                ?: return

        val list = buildList {
            PermissionsAdapter.Item(
                name = "permission.ACCESS_FINE_LOCATION",
                isGranted = ContextCompat.checkSelfPermission(
                    context, Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ).let(::add)
            PermissionsAdapter.Item(
                name = "permission.ACCESS_COARSE_LOCATION",
                isGranted = ContextCompat.checkSelfPermission(
                    context, Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ).let(::add)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                PermissionsAdapter.Item(
                    name = "permission.ACCESS_BACKGROUND_LOCATION (optional from system settings)",
                    isGranted = ContextCompat.checkSelfPermission(
                        context, Manifest.permission.ACCESS_BACKGROUND_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                ).let(::add)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                PermissionsAdapter.Item(
                    name = "permission.POST_NOTIFICATIONS",
                    isGranted = ContextCompat.checkSelfPermission(
                        context, Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED
                ).let(::add)
            }

        }
        adapter.items = list

    }

}