package com.lo.borbalo.navigation


import android.graphics.Rect
import android.view.View
import android.view.ViewGroup
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.forEach
import androidx.core.view.updateLayoutParams
import androidx.core.view.updateMargins
import androidx.core.view.updatePadding


val systemBarInsets = WindowInsetsCompat.Type.systemBars()
val imeInsets = WindowInsetsCompat.Type.ime()

fun View.addSystemTopPadding(
    targetView: View = this,
    isConsumed: Boolean = false
) {
    doOnApplyWindowInsets { _, insets, initialPadding ->
        targetView.updatePadding(
            top = initialPadding.top + insets.getInsets(systemBarInsets).top
        )
        if (isConsumed) {
            WindowInsetsCompat.Builder(insets).setInsets(
                systemBarInsets,
                Insets.of(
                    insets.getInsets(systemBarInsets).left,
                    0,
                    insets.getInsets(systemBarInsets).right,
                    insets.getInsets(systemBarInsets).bottom
                )
            ).build()
        } else {
            insets
        }
    }
}

fun View.addSystemBottomPadding(
    targetView: View = this,
    isConsumed: Boolean = false,
    extraPadding: Int = 0,
) {
    doOnApplyWindowInsets { _, insets, initialPadding ->
        targetView.updatePadding(
            bottom = initialPadding.bottom + extraPadding + insets.getInsets(systemBarInsets).bottom
        )
        if (isConsumed) {
            WindowInsetsCompat.Builder(insets).setInsets(
                systemBarInsets,
                Insets.of(
                    insets.getInsets(systemBarInsets).left,
                    insets.getInsets(systemBarInsets).top,
                    insets.getInsets(systemBarInsets).right,
                    0
                )
            ).build()
        } else {
            insets
        }
    }
}

fun View.addSystemVerticalPadding(
    targetView: View = this,
    isConsumed: Boolean = false,
) {
    doOnApplyWindowInsets { _, insets, initialPadding ->
        targetView.updatePadding(
            bottom = initialPadding.bottom + insets.getInsets(systemBarInsets).bottom,
            top = initialPadding.top + insets.getInsets(systemBarInsets).top,
        )
        if (isConsumed) {
            WindowInsetsCompat.Builder(insets).setInsets(
                systemBarInsets,
                Insets.of(
                    insets.getInsets(systemBarInsets).left,
                    0,
                    insets.getInsets(systemBarInsets).right,
                    0
                )
            ).build()
        } else {
            insets
        }
    }
}

fun View.doOnApplyWindowInsets(block: (View, insets: WindowInsetsCompat, initialPadding: Rect) -> WindowInsetsCompat) {
    val initialPadding = recordInitialPaddingForView(this)
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
        block(v, insets, initialPadding)
    }
    requestApplyInsetsWhenAttached()
}

fun View.dispatchWindowInsetsToChildren() {
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
        (v as? ViewGroup)?.forEach { child -> ViewCompat.dispatchApplyWindowInsets(child, insets) }
        insets
    }
    requestApplyInsetsWhenAttached()
}

private fun recordInitialPaddingForView(view: View): Rect {
    return Rect(view.paddingLeft, view.paddingTop, view.paddingRight, view.paddingBottom)
}

fun View.requestApplyInsetsWhenAttached() {
    if (isAttachedToWindow) {
        ViewCompat.requestApplyInsets(this)
    } else {
        addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {
                v.removeOnAttachStateChangeListener(this)
                ViewCompat.requestApplyInsets(v)
            }

            override fun onViewDetachedFromWindow(v: View) {}
        })
    }
}

fun View.addSystemBottomPaddingOrImeMargin(
    targetView: View = this,
    isConsumed: Boolean = false,
    imeVisibilityChange: ((isIme: Boolean) -> Unit)? = null,
) {
    doOnApplyWindowInsets { _, insets, initialPadding ->
        val isImeVisible = insets.isVisible(imeInsets)
        imeVisibilityChange?.invoke(isImeVisible)
        if (isImeVisible) {
            targetView.updateLayoutParams<ViewGroup.MarginLayoutParams> {
                val size = insets.getInsets(imeInsets).bottom
                updateMargins(bottom = size)
            }
            targetView.updatePadding(bottom = 0)
            return@doOnApplyWindowInsets insets
        } else {
            targetView.updateLayoutParams<ViewGroup.MarginLayoutParams> { updateMargins(bottom = 0) }
            targetView.updatePadding(
                bottom = initialPadding.bottom + insets.getInsets(systemBarInsets).bottom
            )
            return@doOnApplyWindowInsets if (isConsumed) {
                WindowInsetsCompat.Builder(insets).setInsets(
                    systemBarInsets,
                    Insets.of(
                        insets.getInsets(systemBarInsets).left,
                        insets.getInsets(systemBarInsets).top,
                        insets.getInsets(systemBarInsets).right,
                        0
                    )
                ).build()
            } else {
                insets
            }
        }
    }
}